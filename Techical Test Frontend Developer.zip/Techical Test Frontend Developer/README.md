# Techical Test Zettacamp - Frontend Developer

## Introduction

My name is **Muhammad Dzul Fikry** and this is my technical test for the position of **Frontend Developer** at **[ZettaCamp].

## Technology

### 1. HTML and CSS Test

I use **HTML5** and **CSS3** to create the layout of the website. I also use **TailwindCSS** to help me with the styling.

### 2. Javascript Test

I use **JavaScript** to create the algoritm of the website.

to run the code, you can use the command `node searchMedian.js` to run the code.

## Thank You for Your Time 🙏
