// Expected Result = 7
// Direction: Find the median of this array
const inputArray = [8, 7, 7, 9, 5, 4, 2, 9];

function findMedian(input) {
  const sortArray = [...input].sort((a, b) => a - b);

  if (sortArray.length % 2 === 0) {
    // If the array an even number of elements
    const middleIndex = sortArray.length / 2;
    return (sortArray[middleIndex] + sortArray[middleIndex - 1]) / 2;
  } else {
    // If the array an odd number of elements
    const middleIndex = Math.floor(sortArray.length / 2);
    return sortArray[middleIndex];
  }
}

console.log(findMedian(inputArray)); // Output: 7
